export const environment = {
  production: true,

  apiRoot:"http://localhost:3000/api",
};
