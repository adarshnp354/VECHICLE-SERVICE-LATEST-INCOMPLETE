import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';
import { NavServiceService } from '../nav-service.service';


@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  Login_Form: FormGroup;
  login: object;


  

  constructor(private http: HttpClient, private router: Router, private build: FormBuilder, private navservice:NavServiceService) { }

  ngOnInit(): void {

    console.log("login component");
    

    // this.navservice.logged_in=false;

    localStorage.removeItem("User");
    localStorage.removeItem("Address");
    localStorage.removeItem("Mobile");
    localStorage.removeItem("Email");
    localStorage.removeItem("id");
    localStorage.removeItem("token");


    this.Login_Form = this.build.group({
      email: [null, Validators.required],
      password: [null, Validators.required],
    })

  }

  Login() {
    console.log("Login Clicked");

    if (this.Login_Form.valid) {

      var login_data = this.Login_Form.value
      this.http.post(environment.apiRoot + "/login", login_data)
        .subscribe((response) => {
          console.log(response);

          this.login = response;

          if (this.login["token"] != null) {
            localStorage.setItem("User", this.login["name"]);
            localStorage.setItem("Address", this.login["address"]);
            localStorage.setItem("Mobile", this.login["Mob_no"]);
            localStorage.setItem("Email", this.login["email"]);
            localStorage.setItem("id", this.login["id"]);
            localStorage.setItem("token", this.login["token"]);
            // localStorage.setItem("User",this.login["name"]);

            var id = this.login["id"]

            this.http.get(environment.apiRoot + "/user-home/" + id,{
              headers: new HttpHeaders().set('Authorization', this.login["token"]),
            })
              .subscribe((response) => {
                console.log(response);

                if (this.login["token"] != null) {


                  alert("Login Sucess")
                  // this.navservice.logged_in=true;
                  this.navservice.trialfunc()
                  this.router.navigate(['user-home'])

                }
                // else{
                //   this.router.navigate([''])
                // }
              })
            // err => {
            //   console.log(err.message);

            //   this.Login_Form.controls['password'].reset()
            // }
          } else {
            alert(response['msg'])
          }



          // this.http.get(environment.apiRoot+"/user-home")
          // .subscribe((response)=>{
          //   console.log(response);

          // })


        })




      // this.token=localStorage.getItem("token")

      // console.log(this.token);

      // if(this.token!= null){
      // this.router.navigate(['user-home'])
      // }else{
      //   alert("No Token")
      //   console.log("no token dude");

      //   this.router.navigate(['home'])
      // }

    } else {
      console.log("form err says angular");
      alert("Please Check Your Form")

    }







  }



}
