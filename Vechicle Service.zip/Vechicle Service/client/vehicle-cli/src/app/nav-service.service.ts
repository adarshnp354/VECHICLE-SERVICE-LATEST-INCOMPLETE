import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NavServiceService {

  constructor() { }

  // logged_in:boolean;
  user="";
  // token=""

  trialfunc(){
    this.user=localStorage.getItem('User')
    let token=localStorage.getItem('token')

    if(token){
      return true
    }else{
      return false
    }


  }


}
