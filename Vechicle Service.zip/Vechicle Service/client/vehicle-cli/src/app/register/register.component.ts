import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  RegisterForm: FormGroup;
  submitted = false;
  passw_mismatch = false;

  constructor(private router: Router, private build: FormBuilder, private http: HttpClient) { }


  ngOnInit(): void {

    console.log("REG COMPONENT");


    this.RegisterForm = this.build.group({
      name: [null, [Validators.required]],
      password: [null, [Validators.required]],
      confirm_password: [null, [Validators.required]],
      address: [null, [Validators.required]],
      Mob_no: [null, [Validators.required, Validators.pattern('(0|91)?[7-9][0-9]{9}')]],
      email: [null, [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      vehicle_model: [null],
      vehicle_no: [null],
      purchase_date: [null],
      warranty_date: [null],
      Security_Qn: [null, [Validators.required]],
    })


  }



  // convenience getter for easy access to form fields
  get f() { return this.RegisterForm.controls; }

  onSubmit() {
    console.log("clicked");

    this.submitted = true;


    var inp = this.RegisterForm.value;
    // stop here if form is invalid
    if (inp.password !== inp.confirm_password || this.RegisterForm.invalid) {
      console.log("passw not same");
      //    alert("Please Check Your Password")
      this.passw_mismatch = true

    } else {

      // stop here if form is invalid
      // if (this.RegisterForm.invalid) {
      //   console.log("Please Check Your Form");
      // } else {
      this.http.post(environment.apiRoot + "/register", inp)
        .subscribe((response) => {
          console.log(response);
          this.router.navigate(['login'])

        }, (err) => {
          console.log(err);
          alert(err.error)

        })

      

      // }


    }
    // var det = {
    //   "name": inp.name,
    //   "password":inp.password,
    //   "confirm_password":inp.confirm_password,
    //   "address":inp.address,
    //   "Mob_no":inp.Mob_no,
    //   "email":inp.email,
    //   "vehicle_model":inp.vehicle_model,
    //   "vehicle_no":inp.vehicle_no,
    //   "purchase_date":inp.purchase_date,
    //   "warranty_date":inp.warranty_date,
    //   "Security_Qn":inp.Security_Qn,
    // };
    // console.log(det);


  }


}
