import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';


@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {

  token = localStorage.getItem("token") //token
  user_id = localStorage.getItem("id")
  booking_details:any

  constructor(private router:Router,private http:HttpClient) { }



  ngOnInit(): void {

    console.log("USER HOME COMPONENT");
    

    if(this.token == null){
      console.log("token null");
      this.router.navigate(['login'])
    }else{
      this.Booking_details()
    }
    

  }

  Booking_details(){

  }


}
