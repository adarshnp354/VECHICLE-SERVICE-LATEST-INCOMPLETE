import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavServiceService } from '../nav-service.service';



@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  // token = localStorage.getItem("token") //token
  // user = localStorage.getItem("User")
  constructor(public navservice:NavServiceService, private router:Router) { }
  
  ngOnInit(): void {
    

    // if(this.user){
    // console.log(this.user);
    
    // }

    // this.navservice.trialfunc()
    
  }


  logout(){
    localStorage.removeItem("token")
    // this.navservice.logged_in=false
    // this.router.navigate(['login'])
   
    
  }
}
